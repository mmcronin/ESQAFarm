﻿#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration ConfigureWFEServer
{

    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

	[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointFarmAccountcreds,

	[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointSetupUserAccountcreds,

	[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$WebPoolManagedAccountcreds,

	[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$ServicePoolManagedAccountcreds,

	[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointFarmPassphrasecreds,

	[Int]$RetryCount=30,
    [Int]$RetryIntervalSec=60
	
    )
	
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential ]$FarmCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SharePointFarmAccountcreds.UserName)", $SharePointFarmAccountcreds.Password)    
    [System.Management.Automation.PSCredential ]$SPsetupCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SharePointSetupUserAccountcreds.UserName)", $SharePointSetupUserAccountcreds.Password)
    [System.Management.Automation.PSCredential ]$SPWebPoolCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($WebPoolManagedAccountcreds.UserName)", $WebPoolManagedAccountcreds.Password)
    [System.Management.Automation.PSCredential ]$SPServicePoolCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($ServicePoolManagedAccountcreds.UserName)", $ServicePoolManagedAccountcreds.Password)


    Enable-CredSSPNTLM -DomainName $DomainName
    Import-DscResource -ModuleName xComputerManagement, xActiveDirectory, xCertificate, SharePointDsc, xNetworking, xCredSSP, xWebAdministration

Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

	    xCredSSP Server
        {
            Ensure = "Present"
            Role = "Server"
        }

        xCredSSP Client
        {
            Ensure = "Present"
            Role = "Client"
            DelegateComputers = "*.$DomainName", "localhost"
        }

        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }

	    xADUser CreateSetupAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = $SharePointSetupUserAccountcreds.UserName
            Password =$SharePointSetupUserAccountcreds
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin"
        }

        Group AddSetupUserAccountToLocalAdminsGroup
        {
            GroupName = "Administrators"
            Credential = $DomainCreds
            MembersToInclude = "${DomainName}\$($SharePointSetupUserAccountcreds.UserName)"
            Ensure="Present"
            DependsOn = "[xAdUser]CreateSetupAccount"
        }

	    xADUser CreateFarmAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = $SharePointFarmAccountcreds.UserName
            Password = $FarmCreds
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin"
     	}

	    xADUser CreateWebPoolAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = $WebPoolManagedAccountcreds.UserName
            Password = $SPWebPoolCreds
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin"
     	}

	    xADUser CreateServicePoolAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = $ServicePoolManagedAccountcreds.UserName
            Password = $SPServicePoolCreds
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin"
     	}
	
	    xADUser CreateSuperUser
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = "sp_SuperUser"
            Password = $SharePointFarmPassphrasecreds
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin"
     	}

	    xADUser CreateSuperReader
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = "sp_SuperReader"
            Password = $SharePointFarmPassphrasecreds
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin"
     	}

	    xHostsFile intranet
  	    {
   	        HostName = 'sites.esqa.test'
   	        IPAddress = '127.0.0.1'
   	        Ensure = 'Present'
    	}     
         
  	    xHostsFile mysites
  	    {
   	        HostName = 'mysites.esqa.test'
   	        IPAddress = '127.0.0.1'
   	        Ensure = 'Present'
    	}  
		   
        SPInstallPrereqs InstallPrereqs 
	    {
            Ensure            = "Present"
            InstallerPath     = "C:\binaries\prerequisiteinstaller.exe"
            OnlineMode        = $true
        }

        SPInstall InstallSharePoint 
	    {
            Ensure = "Present"
            BinaryDir = "C:\binaries\"
            ProductKey = "6VMND-G3MMT-8QK9P-6WHJM-3GPPJ"
            DependsOn = "[SPInstallPrereqs]InstallPrereqs"
        }

        SPFarm CreateSPFarm
        {
            Ensure                   = "Present"
            DatabaseServer           = "mcesqa-sql.esqa.test"
            FarmConfigDatabaseName   = "SP_Config"
            Passphrase               = $SharePointFarmPassphrasecreds
            FarmAccount              = $FarmCreds
            PsDscRunAsCredential     = $SPsetupCreds
            AdminContentDatabaseName = "SP_AdminContent"
            RunCentralAdmin          = $true
	        ServerRole               = "SingleServerFarm"
            DependsOn                = "[SPInstall]InstallSharePoint"
        }
        SPManagedAccount ServicePoolManagedAccount
        {
            AccountName          = $ServicePoolManagedAccountcreds.UserName
            Account              = $ServicePoolManagedAccountcreds
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }
        SPManagedAccount WebPoolManagedAccount
        {
            AccountName          = $WebPoolManagedAccountcreds.UserName
            Account              = $WebPoolManagedAccountcreds
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }

        SPDiagnosticLoggingSettings ApplyDiagnosticLogSettings
        {
            PsDscRunAsCredential                        = $SPsetupCreds
            LogPath                                     = "C:\ULS"
            LogSpaceInGB                                = 5
            AppAnalyticsAutomaticUploadEnabled          = $false
            CustomerExperienceImprovementProgramEnabled = $true
            DaysToKeepLogs                              = 7
            DownloadErrorReportingUpdatesEnabled        = $false
            ErrorReportingAutomaticUploadEnabled        = $false
            ErrorReportingEnabled                       = $false
            EventLogFloodProtectionEnabled              = $true
            EventLogFloodProtectionNotifyInterval       = 5
            EventLogFloodProtectionQuietPeriod          = 2
            EventLogFloodProtectionThreshold            = 5
            EventLogFloodProtectionTriggerPeriod        = 2
            LogCutInterval                              = 15
            LogMaxDiskSpaceUsageEnabled                 = $true
            ScriptErrorReportingDelay                   = 30
            ScriptErrorReportingEnabled                 = $true
            ScriptErrorReportingRequireAuth             = $true
            DependsOn                                   = "[SPFarm]CreateSPFarm"
        }
        SPUsageApplication UsageApplication 
        {
            Name                  = "Usage Service Application"
            DatabaseName          = "SP_Usage"
            UsageLogCutTime       = 5
            UsageLogLocation      = "C:\UsageLogs"
            UsageLogMaxFileSizeKB = 1024
            PsDscRunAsCredential  = $SPsetupCreds
            DependsOn             = "[SPFarm]CreateSPFarm"
        }
        SPStateServiceApp StateServiceApp
        {
            Name                 = "State Service Application"
            DatabaseName         = "SP_State"
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }
        SPDistributedCacheService EnableDistributedCache
        {
            Name                 = "AppFabricCachingService"
            Ensure               = "Present"
            CacheSizeInMB        = 1024
            ServiceAccount       = $ServicePoolManagedAccountcreds.UserName
            PsDscRunAsCredential = $SPsetupCreds
            CreateFirewallRules  = $true
            DependsOn            = @('[SPFarm]CreateSPFarm','[SPManagedAccount]ServicePoolManagedAccount')
        }

        SPWebApplication SharePointSites
        {
            Name                   = "Intranet"
            ApplicationPool        = "Intranet"
            ApplicationPoolAccount = $WebPoolManagedAccountcreds.UserName
            AllowAnonymous         = $false
            AuthenticationMethod   = "NTLM"
            DatabaseName           = "SP_Content"
            UseSSL                 = $true
            Url                    = "https://sites.esqa.test"
            HostHeader             = "sites.esqa.test"
            Port                   = 443
            PsDscRunAsCredential   = $SPsetupCreds
            DependsOn              = "[SPManagedAccount]WebPoolManagedAccount"
        }
	
        SPCacheAccounts WebAppCacheAccounts
        {
            WebAppUrl              = "https://sites.esqa.test"
            SuperUserAlias         = "esqa\sp_SuperUser"
            SuperReaderAlias       = "esqa\sp_SuperReader"
            PsDscRunAsCredential   = $SPsetupCreds
            DependsOn              = "[SPWebApplication]SharePointSites"
        }

        SPSite TeamSite
        {
            Url                      = "https://sites.esqa.test"
            OwnerAlias               = "esqa\esqaadmin"
            Name                     = "DSC Demo Site"
            Template                 = "STS#0"
            PsDscRunAsCredential     = $SPsetupCreds
            DependsOn                = "[SPWebApplication]SharePointSites"
        }

         SPWebApplication MySites
        {
            Name                   = "My Sites"
            ApplicationPool        = "My Sites"
            ApplicationPoolAccount = $WebPoolManagedAccountCreds.UserName
            AllowAnonymous         = $false
            AuthenticationMethod   = "NTLM"
            DatabaseName           = "SP_MySites"
            UseSSL                 = $true
            Url                    = "https://mysites.esqa.test"
            HostHeader             = "mysites.esqa.test"
            Port                   = 443
            PsDscRunAsCredential   = $SPsetupCreds
            DependsOn              = "[SPManagedAccount]WebPoolManagedAccount"
        }
        
        SPCacheAccounts MySiteWebAppCacheAccounts
        {
            WebAppUrl              = "https://mysites.esqa.test"
            SuperUserAlias         = "esqa\sp_superuser"
            SuperReaderAlias       = "esqa\sp_superreader"
            PsDscRunAsCredential   =  $SPsetupCreds
            DependsOn              = "[SPWebApplication]MySites"
        }

        SPSite MySites
        {
            Url                      = "https://mysites.esqa.test"
            OwnerAlias               = "esqa\esqaadmin"
            Name                     = "DSC Demo My Sites"
            Template                 = "SPSMSITEHOST#0"
            PsDscRunAsCredential     = $SPsetupCreds
            DependsOn                = "[SPWebApplication]MySites"
        }

        SPServiceInstance ClaimsToWindowsTokenServiceInstance
        {  
            Name                 = "Claims to Windows Token Service"
            Ensure               = "Present"
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }   

        SPServiceInstance SecureStoreServiceInstance
        {  
            Name                 = "Secure Store Service"
            Ensure               = "Present"
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }
        
        SPServiceInstance ManagedMetadataServiceInstance
        {  
            Name                 = "Managed Metadata Web Service"
            Ensure               = "Present"
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }

        SPServiceInstance BCSServiceInstance
        {  
            Name                 = "Business Data Connectivity Service"
            Ensure               = "Present"
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }
        
        SPServiceInstance SearchServiceInstance
        {  
            Name                 = "SharePoint Server Search"
            Ensure               = "Present"
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }
	
        $serviceAppPoolName = "SharePoint Service Applications"
        SPServiceAppPool MainServiceAppPool
        {
            Name                 = $serviceAppPoolName
            ServiceAccount       = $SPServicePoolCreds.UserName
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }

        SPSecureStoreServiceApp SecureStoreServiceApp
        {
            Name                  = "Secure Store Service Application"
            ApplicationPool       = $serviceAppPoolName
            AuditingEnabled       = $true
            AuditlogMaxSize       = 30
            DatabaseName          = "SP_SecureStore"
            PsDscRunAsCredential  = $SPsetupCreds
            DependsOn             = "[SPServiceAppPool]MainServiceAppPool"
        }
        
        SPManagedMetaDataServiceApp ManagedMetadataServiceApp
        {  
            Name                 = "Managed Metadata Service Application"
            PsDscRunAsCredential = $SPsetupCreds
            ApplicationPool      = $serviceAppPoolName
            DatabaseName         = "SP_MMS"
            DependsOn            = "[SPServiceAppPool]MainServiceAppPool"
        }

        SPBCSServiceApp BCSServiceApp
        {
            Name                  = "BCS Service Application"
            ApplicationPool       = $serviceAppPoolName
            DatabaseName          = "SP_BCS"
	        DatabaseServer        = "mcesqa-sql.esqa.test"
	        PsDscRunAsCredential  = $SPsetupCreds
            DependsOn             = @('[SPServiceAppPool]MainServiceAppPool', '[SPSecureStoreServiceApp]SecureStoreServiceApp')
        }

        SPSearchServiceApp SearchServiceApp
        {  
            Name                  = "Search Service Application"
            DatabaseName          = "SP_Search"
            ApplicationPool       = $serviceAppPoolName
            PsDscRunAsCredential  = $SPsetupCreds
            DependsOn             = "[SPServiceAppPool]MainServiceAppPool"
        }

         SPUserProfileServiceApp UserProfileServiceApp
        {
            Name                 = "User Profile Service Application"
	        Ensure               = "Present"
	        ApplicationPool      = $serviceAppPoolName
            MySiteHostLocation   = "https://mysites.esqa.test"
            ProfileDBName        = "SP_UserProfiles"
            ProfileDBServer      = "mcesqa-sql.esqa.test"
            SocialDBName         = "SP_Social"
            SocialDBServer       = "mcesqa-sql.esqa.test"
            SyncDBName           = "SP_ProfileSync"
            SyncDBServer         = "mcesqa-sql.esqa.test"
            EnableNetBIOS        = $false
            FarmAccount          = $FarmCreds
            PsDscRunAsCredential = $SPsetupCreds
	        DependsOn            = "[SPFarm]CreateSPFarm"
         }
	
        xPfxImport CompanyCert
        {
            Thumbprint = '73823F0876312DCE3186CA63BACB63C706A61186'
            Path       = 'c:\scripts\Cert.pfx'
            Location   = 'LocalMachine'
            Store      = 'My'
            Credential = $DomainCreds
        }

	 xWebsite SSLBind-Intranet
        { 
            Ensure          = "Present" 
            Name            = "Intranet"
	        BindingInfo     = MSFT_xWebBindingInformation 
                             { 
                               Protocol              = "HTTPS" 
			                   Hostname		     = "sites.esqa.test"
                               Port                  = 443 
                               CertificateThumbprint = "73823F0876312DCE3186CA63BACB63C706A61186" 
                               CertificateStoreName  = "My" 
                             } 
	        DependsOn           = "[SPWebApplication]SharePointSites"
        } 
        	
	xWebsite SSLBind-MySites
        { 
            Ensure          = "Present" 
            Name            = "My Sites"
	        BindingInfo     = MSFT_xWebBindingInformation 
                             { 
                               Protocol              = "HTTPS" 
			                   Hostname		     = "mysites.esqa.test"
                               Port                  = 443 
                               CertificateThumbprint = "73823F0876312DCE3186CA63BACB63C706A61186" 
                               CertificateStoreName  = "My" 
                             } 
	        DependsOn           = "[SPWebApplication]MySites"
        } 

    }
}

function Enable-CredSSPNTLM
{
    param(
        [Parameter(Mandatory=$true)]
        [string]$DomainName
    )

    # This is needed for the case where NTLM authentication is used

    Write-Verbose 'STARTED:Setting up CredSSP for NTLM'

    Enable-WSManCredSSP -Role client -DelegateComputer localhost, *.$DomainName -Force -ErrorAction SilentlyContinue
    Enable-WSManCredSSP -Role server -Force -ErrorAction SilentlyContinue

    if(-not (Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -ErrorAction SilentlyContinue))
    {
        New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows -Name '\CredentialsDelegation' -ErrorAction SilentlyContinue
    }

    if( -not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -value '1' -PropertyType dword -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'ConcatenateDefaults_AllowFreshNTLMOnly' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'ConcatenateDefaults_AllowFreshNTLMOnly' -value '1' -PropertyType dword -ErrorAction SilentlyContinue
    }

    if(-not (Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -ErrorAction SilentlyContinue))
    {
        New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '1' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '1' -value "wsman/$env:COMPUTERNAME" -PropertyType string -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '2' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '2' -value "wsman/localhost" -PropertyType string -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '3' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '3' -value "wsman/*.$DomainName" -PropertyType string -ErrorAction SilentlyContinue
    }

    Write-Verbose "DONE:Setting up CredSSP for NTLM"
}

