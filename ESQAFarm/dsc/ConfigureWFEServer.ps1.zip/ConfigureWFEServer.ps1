﻿#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration ConfigureWFEServer
{

    param
    (

	[Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SetupAccountCreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$FarmAccountCreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$WebPoolManagedAccountCreds,

	[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointFarmPassphraseCreds	

      )

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)
        [System.Management.Automation.PSCredential ]$SetUpAccountCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SetupAccountCreds.UserName)", $SetupAccountCreds.Password)
	[System.Management.Automation.PSCredential ]$FarmAccountCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($FarmAccountCreds.UserName)", $FarmAccountCreds.Password)
	[System.Management.Automation.PSCredential ]$WebPoolManagedAccountCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($WebPoolManagedAccountCreds.UserName)", $WebPoolManagedAccountCreds.Password)

    Enable-CredSSPNTLM -DomainName $DomainName
    Import-DscResource -ModuleName xComputerManagement, xNetworking, xActiveDirectory, SharePointDSC, xCredSSP
   
    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
	xCredSSP Server
        {
            Ensure = "Present"
            Role = "Server"
        }
        xCredSSP Client
        {
            Ensure = "Present"
            Role = "Client"
            DelegateComputers = "*.$Domain", "localhost"
        }
	xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
        }
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }

       	 xADUser CreateSetupAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = $SetupAccountCreds.UserName
            Password =$SetupAccountCreds
            Ensure = "Present"
	    DependsOn = "[xComputer]DomainJoin"
         }
        Group AddSetupUserAccountToLocalAdminsGroup
        {
            GroupName = "Administrators"
            Credential = $DomainCreds
            MembersToInclude = "${DomainName}\$($SetupAccountCreds.UserName)"
            Ensure="Present"
	    DependsOn = "[xAdUser]CreateSetupAccount"
         }

        xADUser CreateFarmAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = $FarmAccountCreds.UserName
            Password =$FarmAccountCreds
            Ensure = "Present"
	    DependsOn = "[xComputer]DomainJoin"
        }
 	
	xADUser CreateWebPoolAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = $WebPoolManagedAccountCreds.UserName
            Password =$WebPoolManagedAccountCreds
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin"
        }

	#**********************************************************
        # Install Binaries
        #
        # This section installs SharePoint and its Prerequisites
        #**********************************************************
        
        SPInstallPrereqs InstallPrereqs {
            Ensure            = "Present"
            InstallerPath     = "C:\binaries\prerequisiteinstaller.exe"
            OnlineMode        = $true
        }

        SPInstall InstallSharePoint {
            Ensure = "Present"
            BinaryDir = "C:\binaries\"
            ProductKey = "6VMND-G3MMT-8QK9P-6WHJM-3GPPJ"
            DependsOn = "[SPInstallPrereqs]InstallPrereqs"
        }

        #**********************************************************
        # Basic farm configuration
        #
        # This section creates the new SharePoint farm object, and
        # provisions generic services and components used by the
        # whole farm
        #**********************************************************
        SPFarm CreateSPFarm
        {
            Ensure                   = "Present"
            DatabaseServer           = "mcesqa-sql.esqa.test"
            FarmConfigDatabaseName   = "SP_Config"
            Passphrase               = $SharePointFarmPassphraseCreds
            FarmAccount              = $FarmAccountCreds
            PsDscRunAsCredential     = $SetupAccountCreds
            AdminContentDatabaseName = "SP_AdminContent"
            RunCentralAdmin          = $true
	    ServerRole               = "SingleServerFarm"
            DependsOn                = "[SPInstall]InstallSharePoint"
        }
        SPManagedAccount WebPoolManagedAccount
        {
            AccountName          = $WebPoolManagedAccountCreds.UserName
            Account              = $WebPoolManagedAccountCreds
            PsDscRunAsCredential = $SetupAccountCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }
        SPDiagnosticLoggingSettings ApplyDiagnosticLogSettings
        {
            PsDscRunAsCredential                        = $SPSetupAccount
            LogPath                                     = "C:\ULS"
            LogSpaceInGB                                = 5
            AppAnalyticsAutomaticUploadEnabled          = $false
            CustomerExperienceImprovementProgramEnabled = $true
            DaysToKeepLogs                              = 7
            DownloadErrorReportingUpdatesEnabled        = $false
            ErrorReportingAutomaticUploadEnabled        = $false
            ErrorReportingEnabled                       = $false
            EventLogFloodProtectionEnabled              = $true
            EventLogFloodProtectionNotifyInterval       = 5
            EventLogFloodProtectionQuietPeriod          = 2
            EventLogFloodProtectionThreshold            = 5
            EventLogFloodProtectionTriggerPeriod        = 2
            LogCutInterval                              = 15
            LogMaxDiskSpaceUsageEnabled                 = $true
            ScriptErrorReportingDelay                   = 30
            ScriptErrorReportingEnabled                 = $true
            ScriptErrorReportingRequireAuth             = $true
            DependsOn                                   = "[SPFarm]CreateSPFarm"
        }
        SPUsageApplication UsageApplication 
        {
            Name                  = "Usage Service Application"
            DatabaseName          = "SP_Usage"
            UsageLogCutTime       = 5
            UsageLogLocation      = "C:\UsageLogs"
            UsageLogMaxFileSizeKB = 1024
            PsDscRunAsCredential  = $SetupAccountCreds
            DependsOn             = "[SPFarm]CreateSPFarm"
        }
        SPStateServiceApp StateServiceApp
        {
            Name                 = "State Service Application"
            DatabaseName         = "SP_State"
            PsDscRunAsCredential = $SetupAccountCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }
        SPDistributedCacheService EnableDistributedCache
        {
            Name                 = "AppFabricCachingService"
            Ensure               = "Present"
            CacheSizeInMB        = 1024
            ServiceAccount       = $WebPoolManagedAccountCreds.UserName
            PsDscRunAsCredential = $SetupAccountCreds
            CreateFirewallRules  = $true
            DependsOn            = @('[SPFarm]CreateSPFarm','[SPManagedAccount]WebPoolManagedAccount')
        }

        #**********************************************************
        # Web applications
        #
        # This section creates the web applications in the 
        # SharePoint farm, as well as managed paths and other web
        # application settings
        #**********************************************************

        SPWebApplication SharePointSites
        {
            Name                   = "Intranet"
            ApplicationPool        = "Intranet"
            ApplicationPoolAccount = $WebPoolManagedAccountCreds.UserName
            AllowAnonymous         = $false
            AuthenticationMethod   = "NTLM"
            DatabaseName           = "SP_Content"
            UseSSL                 = $true
            Url                    = "https://sites.esqa.test"
            HostHeader             = "sites.esqa.test"
            Port                   = 443
            PsDscRunAsCredential   = $SetupAccountCreds
            DependsOn              = "[SPManagedAccount]WebPoolManagedAccount"
        }
        
        SPCacheAccounts WebAppCacheAccounts
        {
            WebAppUrl              = "https://sites.esqa.test"
            SuperUserAlias         = "esqa\SP_SuperUser"
            SuperReaderAlias       = "esqa\SP_SuperReader"
            PsDscRunAsCredential   = $SetupAccountCreds
            DependsOn              = "[SPWebApplication]SharePointSites"
        }

        SPSite TeamSite
        {
            Url                      = "https://sites.esqa.test"
            OwnerAlias               = "esqa\esqaadmin"
            Name                     = "DSC Demo Site"
            Template                 = "STS#0"
            PsDscRunAsCredential     = $SPSetupAccountCreds
            DependsOn                = "[SPWebApplication]SharePointSites"
        }

         SPWebApplication MySites
        {
            Name                   = "My Sites"
            ApplicationPool        = "My Sites"
            ApplicationPoolAccount = $WebPoolManagedAccountCreds.UserName
            AllowAnonymous         = $false
            AuthenticationMethod   = "NTLM"
            DatabaseName           = "SP_MySites"
            UseSSL                 = $true
            Url                    = "https://mysites.esqa.test"
            HostHeader             = "mysites.esqa.test"
            Port                   = 443
            PsDscRunAsCredential   = $SetupAccountCreds
            DependsOn              = "[SPManagedAccount]WebPoolManagedAccount"
        }
        
        SPCacheAccounts MySiteWebAppCacheAccounts
        {
            WebAppUrl              = "https://mysites.esqa.test"
            SuperUserAlias         = "esqa\SP_SuperUser"
            SuperReaderAlias       = "esqa\SP_SuperReader"
            PsDscRunAsCredential   = $SetupAccountCreds
            DependsOn              = "[SPWebApplication]MySites"
        }

        SPSite MySites
        {
            Url                      = "https://mysites.esqa.test"
            OwnerAlias               = "esqa\esqaadmin"
            Name                     = "DSC Demo My Sites"
            Template                 = "SPSMSITEHOST#0"
            PsDscRunAsCredential     = $SetupAccountCreds
            DependsOn                = "[SPWebApplication]MySites"
        }

        #**********************************************************
        # Service instances
        #
        # This section describes which services should be running
        # and not running on the server
        #**********************************************************

        SPServiceInstance ClaimsToWindowsTokenServiceInstance
        {  
            Name                 = "Claims to Windows Token Service"
            Ensure               = "Present"
            PsDscRunAsCredential = $SetupAccountCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }   

        SPServiceInstance SecureStoreServiceInstance
        {  
            Name                 = "Secure Store Service"
            Ensure               = "Present"
            PsDscRunAsCredential = $SetupAccountCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }
        
        SPServiceInstance ManagedMetadataServiceInstance
        {  
            Name                 = "Managed Metadata Web Service"
            Ensure               = "Present"
            PsDscRunAsCredential = $SetupAccountCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }

        SPServiceInstance BCSServiceInstance
        {  
            Name                 = "Business Data Connectivity Service"
            Ensure               = "Present"
            PsDscRunAsCredential = $SetupAccountCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }
        
        SPServiceInstance SearchServiceInstance
        {  
            Name                 = "SharePoint Server Search"
            Ensure               = "Present"
            PsDscRunAsCredential = $SetupAccountCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }
	
	#**********************************************************
        # Service applications
        #
        # This section creates service applications and required
        # dependencies
        #**********************************************************

        $serviceAppPoolName = "SharePoint Service Applications"
        SPServiceAppPool MainServiceAppPool
        {
            Name                 = $serviceAppPoolName
            ServiceAccount       = $WebPoolManagedAccountCreds.UserName
            PsDscRunAsCredential = $SetupAccountCreds
            DependsOn            = "[SPFarm]CreateSPFarm"
        }

        SPSecureStoreServiceApp SecureStoreServiceApp
        {
            Name                  = "Secure Store Service Application"
            ApplicationPool       = $serviceAppPoolName
            AuditingEnabled       = $true
            AuditlogMaxSize       = 30
            DatabaseName          = "SP_SecureStore"
            PsDscRunAsCredential  = $SetupAccountCreds
            DependsOn             = "[SPServiceAppPool]MainServiceAppPool"
        }
        
        SPManagedMetaDataServiceApp ManagedMetadataServiceApp
        {  
            Name                 = "Managed Metadata Service Application"
            PsDscRunAsCredential = $SetupAccountCreds
            ApplicationPool      = $serviceAppPoolName
            DatabaseName         = "SP_MMS"
            DependsOn            = "[SPServiceAppPool]MainServiceAppPool"
        }

        SPBCSServiceApp BCSServiceApp
        {
            Name                  = "BCS Service Application"
            ApplicationPool       = $serviceAppPoolName
            DatabaseName          = "SP_BCS"
	    DatabaseServer        = "mcesqa-sql.esqa.test"
	    PsDscRunAsCredential  = $SetupAccountCreds
            DependsOn             = @('[SPServiceAppPool]MainServiceAppPool', '[SPSecureStoreServiceApp]SecureStoreServiceApp')
        }

        SPSearchServiceApp SearchServiceApp
        {  
            Name                  = "Search Service Application"
            DatabaseName          = "SP_Search"
            ApplicationPool       = $serviceAppPoolName
            PsDscRunAsCredential  = $SetupAccountCreds
            DependsOn             = "[SPServiceAppPool]MainServiceAppPool"
        }
         SPUserProfileServiceApp UserProfileServiceApp
        {
            Name                 = "User Profile Service Application"
	    Ensure               = "Present"
	    ApplicationPool      = $serviceAppPoolName
            MySiteHostLocation   = "https://mysites.esqa.test"
            ProfileDBName        = "SP_UserProfiles"
            ProfileDBServer      = "mcesqa-sql.esqa.test"
            SocialDBName         = "SP_Social"
            SocialDBServer       = "mcesqa-sql.esqa.test"
            SyncDBName           = "SP_ProfileSync"
            SyncDBServer         = "mcesqa-sql.esqa.test"
            EnableNetBIOS        = $false
            FarmAccount          = $FarmAccountCreds
            PsDscRunAsCredential = $SetupAccountCreds
	    DependsOn            = "[SPFarm]CreateSPFarm"
         }
   }
}

function Enable-CredSSPNTLM
{
    param(
        [Parameter(Mandatory=$true)]
        [string]$DomainName
    )

    # This is needed for the case where NTLM authentication is used

    Write-Verbose 'STARTED:Setting up CredSSP for NTLM'

    Enable-WSManCredSSP -Role client -DelegateComputer localhost, *.$DomainName -Force -ErrorAction SilentlyContinue
    Enable-WSManCredSSP -Role server -Force -ErrorAction SilentlyContinue

    if(-not (Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -ErrorAction SilentlyContinue))
    {
        New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows -Name '\CredentialsDelegation' -ErrorAction SilentlyContinue
    }

    if( -not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -value '1' -PropertyType dword -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'ConcatenateDefaults_AllowFreshNTLMOnly' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'ConcatenateDefaults_AllowFreshNTLMOnly' -value '1' -PropertyType dword -ErrorAction SilentlyContinue
    }

    if(-not (Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -ErrorAction SilentlyContinue))
    {
        New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '1' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '1' -value "wsman/$env:COMPUTERNAME" -PropertyType string -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '2' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '2' -value "wsman/localhost" -PropertyType string -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '3' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '3' -value "wsman/*.$DomainName" -PropertyType string -ErrorAction SilentlyContinue
    }

    Write-Verbose "DONE:Setting up CredSSP for NTLM"
}

