﻿#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration ConfigureWFEServer
{

    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
	
	[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$FarmAccountCreds,

        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=60
    )
	
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential ]$FarmAccountCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($FarmAccountCreds.UserName)", $FarmAccountCreds.Password)
    
    Enable-CredSSPNTLM -DomainName $DomainName
    Import-DscResource -ModuleName xComputerManagement, xActiveDirectory, xNetworking, xCredSSP

Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

	xCredSSP Server
        {
            Ensure = "Present"
            Role = "Server"
        }

        xCredSSP Client
        {
            Ensure = "Present"
            Role = "Client"
            DelegateComputers = "*.$Domain", "localhost"
        }

        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }
	
	xADUser CreateFarmAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = $FarmAccountCreds.UserName
            Password =$FarmAccountCreds
            Ensure = "Present"
  	}

      }
}


